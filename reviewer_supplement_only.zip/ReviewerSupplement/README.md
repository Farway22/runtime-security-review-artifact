# Standalone reviewer supplement

This artifact accompanies **From Context Poisoning to Persistent Compromise: A Systematic Review of Runtime Threat Propagation in Autonomous LLM Agent Frameworks**. The current synthesis contains **229 primary studies**. The data snapshot is dated 2026-10-12; this portable public export was prepared on 2026-10-14. No study-level coding value was changed for publication of the artifact.

This attachment contains only supplementary data, methods, evidence records and replay scripts. It does not contain the manuscript PDF, LaTeX source, bibliography, figures or compilation dependencies. Start with `REVIEWER_GUIDE.md`.

## Suggested reading order

Start with the [reviewer guide](REVIEWER_GUIDE.md), which maps manuscript claims to the data, field reasons, reviewed sources and replay commands.

1. [Final study-level dataset](data/final_core229_2026-10-12.tsv): IDs, titles, CASO, primary paths, Q1–Q5, totals, quality labels and endpoints.
2. [Coding and synthesis methods](methods/methodology_coding_details.md) and [data dictionary](methods/DATA_DICTIONARY.md).
3. [Field-level evidence index](data/core_field_evidence229.json), [central comparative evidence](evidence/central_comparisons.md), [descriptive extraction matrix](data/descriptive_extraction229.tsv), [reviewed-source index](data/source_index.json), and [active evidence-anchored decisions](data/core_field_adjudication.json).
4. [Search and selection records](search/README.md).
5. [Numerical replay](scripts/reproduce_statistics.mjs) and the sensitivity scripts below.

The dataset above is the final quantitative reference. Descriptive extraction and archival search records preserve supporting evidence; they do not supply an alternative set of final quality scores or path assignments.

## Reproduce

Requires Node.js 20 or later. There are **no third-party packages**, network calls, private-workspace requirements, or original-paper PDFs required for numerical replay. From this directory:

```sh
node scripts/reproduce_statistics.mjs
node scripts/check_review_traceability.mjs
node scripts/analyze_route_selection_2026-10-12.mjs --summary
node scripts/analyze_recorded_disagreements_2026-10-12.mjs --summary
```

The scripts resolve their inputs relative to their own locations and can also be invoked by absolute path from another directory. These commands are read-only. They check data identity, aggregate counts, original paired agreement, selected-study membership, decision values, and the specified sensitivity calculations. [Recorded outputs](results/) are supplied for inspection. `manifest.json` lists SHA-256 hashes of public files.

Expected headline totals:

| Quantity | Final count |
|---|---:|
| Primary studies | 229 |
| E1 / E2 / E3 / E4 / E5 / E6 | 4 / 9 / 99 / 68 / 48 / 1 |
| High / moderate / low reporting quality | 213 / 13 / 3 |
| Directed / single-node / UND primary assignments | 148 / 5 / 76 |
| Complete C>A primary assignment | 96 |
| C>A adjacent-edge incidence | 120 |

CASO labels overlap. A complete path count and an adjacent-edge count are different quantities. UND means **no uniquely supported primary-route assignment**, not unfinished coding. Several independently evaluated routes and insufficient evidence for one route are distinct reasons that are not separately counted in the sealed dataset.

## Interpretation and scope

Eligibility uses **first public availability, January 2022–June 2026**. Synthesis uses the full-text revision actually reviewed, which may be later. Version-specific URLs and dates are provided where recoverable from the reviewed source; missing version metadata is left null. This is not a census of results available by June 2026.

Independent core-field coding covered all 229 studies. Historical recorded values, independent first-pass judgments and final adjudication are distinct. Original paired judgments are retained in the statistics JSON to reproduce agreement without substituting adjudicated values. The two original rule-version panels are not pooled into a final-rule blind coefficient. Independent endpoint/property/handoff assessment was sample-based; the public methods explain its scope. Public replay verifies arithmetic and data consistency, **not coding correctness or independent repeatability under the final clarified rules**.

The supported-route analysis enumerates 864 combinations over eight selected multipath studies with the other 221 assignments fixed. The recorded-disagreement analysis separately varies archived path and CASO labels, including judgments rejected in adjudication. These are specified sensitivity spaces, not confidence intervals, equally valid recodings, or estimates of real-world attack prevalence. Endpoints remain publication-level attributes, not automatically validated outcomes of hypothetical selected routes.

## Files and provenance

`data/final_core229_2026-10-12.tsv` is byte-identical to the sealed TSV. The statistics JSON preserves study values, original paired judgments and aggregate results, but removes outdated process-counter metadata and replaces local paths with non-downloadable provenance basenames. The reviewed-source index and decision records are sanitized exports; original research inputs remain unchanged.

The descriptive matrix retains source-level summaries and page anchors, not fresh independent judgments of every qualitative field. Author-provided artifact links are recorded as reported; their continuing availability is not guaranteed. Historical codebooks v1.0 and v1.1 are retained to interpret original judgments; the current method note also incorporates final adjudication clarifications.

Original paper PDFs, extracted full texts, private local paths, internal review reports and unrelated project history are **not redistributed**. Obtain source papers through the persistent and reviewed-version URLs. Source hashes identify reviewed files; without those files they do not independently verify their contents. Rights and licenses of linked papers and third-party artifacts remain with their respective owners.
