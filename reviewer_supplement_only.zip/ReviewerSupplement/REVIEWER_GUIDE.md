# Reviewer guide: from a claim to its evidence

The associated manuscript synthesizes 229 studies. This standalone attachment contains supporting materials only; the manuscript itself is not included. The materials below allow inspection of study membership, final coding, original reasons, source versions and the calculations used in the synthesis. They are organized by review question rather than by the internal chronology of the project.

## Where to check

| Review question | Materials | What to inspect |
|---|---|---|
| Which studies were selected, and why? | [Search and selection guide](search/README.md), final eligibility tables and [final dataset](data/final_core229_2026-10-12.tsv) | Candidate reconciliation, eligibility reasons and exact membership of the 229-study synthesis. Intermediate screening labels are not final membership. |
| Why was a study assigned a CASO label, primary path or quality score? | [Field-level evidence index](data/core_field_evidence229.json), [coding methods](methods/methodology_coding_details.md) and [dictionary](methods/DATA_DICTIONARY.md) | Search by stable `ID` and `field`; read `finalValue`, `finalEvidence`, and the original note separately. Follow the linked source to its recorded pages. |
| Does a cited mechanism support the central comparison? | [Central comparative evidence](evidence/central_comparisons.md) and [descriptive extraction](data/descriptive_extraction229.tsv) | Reviewed source, PDF pages, observed behavior, and the limit of the inference. Worked illustrations are distinguished from comparative experiments. |
| How were path and endpoint summaries calculated? | [Final data](data/final_core229_2026-10-12.tsv), [statistics](data/final_core_statistics_2026-10-12.json), [numerical replay](scripts/reproduce_statistics.mjs) | Complete assignments versus adjacent edges; denominator; overlapping CASO versus mutually exclusive path groups; publication-level endpoint versus path-specific outcome. |
| Which full-text version was actually used? | [Reviewed-source index](data/source_index.json) | Persistent source, reviewed-version URL/date where recoverable, reviewed-file hashes and page count. Eligibility date and reviewed revision are different attributes. |
| What supports agreement and sensitivity statements? | [Method details](methods/methodology_coding_details.md), original pairs in the statistics JSON, [route cases](data/route_selection_cases_2026-10-12.json) and [recorded sensitivity inputs](data/recorded_disagreement_input_2026-10-12.json) | Original independent comparisons, their rule versions and scope; the exact specified alternatives used in sensitivity calculations. Adjudicated values are not substituted into independent agreement. |

## Following an individual study

1. Find its title and stable `ID` in the final dataset. This is the quantitative reference.
2. In the field-level evidence index, find that `ID` and the relevant `field`. `finalEvidence` supplies the reason retained for the final value; `independentFirstPass` preserves the original judgment and note, which can differ from the final decision.
3. Open `sourceUrl`, using the reviewed revision where one is identified. Check the specified pages against the rule in the method note. The reviewed-source index identifies the reviewed file; a hash is an identity check, not a substitute for reading it.
4. Use the descriptive extraction for study setting, attacker access, mechanisms and evaluation details. A generic extraction note such as “page-level verification recommended” is not a precise evidence locator.

For example, the **96 complete C>A assignments** and **120 studies containing the C>A adjacent edge** can both be checked from the final paths. They are not competing estimates: a multi-hop assignment can contain the edge without being exactly C>A. Similarly, **76 UND assignments** mean that one primary route was not uniquely supported; they do not mean 76 studies were left uncoded. Their study-specific notes, rather than a blanket explanation, are the appropriate evidence.

For a qualitative example, **U078 (The Containment Gap)** is linked in the central comparative register to PDF pages 4–6. The register distinguishes prevention of a suspect write from post-hoc repair, and separates individually tested controls from an observed joint protection chain. This lets the reader inspect both the evidence and the scope of the synthesis.

## Coverage of the evidence index

All **1,603 values across seven core fields in 229 studies** are linked to original independent notes. Of these, **677** have an active full-text adjudication with page anchors; **one** retains an earlier matching adjudication; **925** retain a matching original first-pass note. Earlier and original locators are preserved as recorded, not silently revalidated or replaced. Notes remain in their original language.

This index covers CASO, primary paths and Q1–Q5. Endpoint, property and handoff records have different assessment coverage; their independent assessment was sample-based, as specified in the methods. The endpoint labels are available for all 229 studies, but the index does not imply fresh independent full-corpus endpoint validation. The eight source-to-claim entries target the central comparisons, not every sentence of the review.

## Reproduce and check file identity

From this artifact directory, using Node.js 20+ with no additional packages:

```sh
node scripts/reproduce_statistics.mjs
node scripts/check_review_traceability.mjs
node scripts/analyze_route_selection_2026-10-12.mjs --summary
node scripts/analyze_recorded_disagreements_2026-10-12.mjs --summary
```

[Recorded outputs](results/) and the [file-hash manifest](manifest.json) accompany the inputs. The checks reproduce specified calculations and verify that exported reasons and values match their archived records. They do not automatically establish the correctness of a semantic judgment or reproduce the original papers' experiments.

Original-paper full texts are not redistributed. Source URLs enable retrieval subject to their access conditions. The search guide identifies the deposited records and the raw retrieval materials that are not included, so the scope of the audit trail is explicit.
