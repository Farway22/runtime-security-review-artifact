// Read-only identity and coverage checks; no semantic recoding.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=name=>JSON.parse(fs.readFileSync(path.join(root,name),'utf8').replace(/^\uFEFF/,''));
const index=read('data/core_field_evidence229.json');
const snapshot=read('data/final_core_statistics_2026-10-12.json');
const ledger=read('data/core_field_adjudication.json');
const sources=read('data/source_index.json');
const studies=new Map(snapshot.records.map(r=>[r.ID,r]));
const decisions=new Map(ledger.decisions.map(d=>[d.ID+'|'+d.field,d]));
const bySource=new Map(sources.items.map(s=>[s.Real_ID,s]));
const keys=new Set(),panels=new Set(),kinds={};
for(const r of index.records){
 const key=r.ID+'|'+r.field;assert(!keys.has(key));keys.add(key);
 const study=studies.get(r.ID),source=bySource.get(r.ID);assert(study&&source);
 assert.equal(r.finalValue,String(study.core[r.field]));
 assert.equal(r.sourcePdfSha256,source.pdfSha256);
 assert.equal(r.sourceTextSha256,source.textSha256);
 assert.equal(r.sourceUrl,source.reviewedVersionUrl??source.persistentSource);
 const original=r.independentFirstPass;
 const pair=snapshot.reliability[original.panel].paired[r.field][original.pairIndex];
 assert.equal(r.historicalRecordedValue,pair[0]);assert.equal(original.value,pair[1]);
 assert(original.recordedLocator&&original.rationale);
 const pairKey=original.panel+'|'+original.pairIndex+'|'+r.field;
 assert(!panels.has(pairKey));panels.add(pairKey);
 const evidence=r.finalEvidence,decision=decisions.get(key);
 kinds[evidence.kind]=(kinds[evidence.kind]??0)+1;
 if(decision){
  assert.equal(evidence.kind,'active_full_text_adjudication');
  assert.equal(r.finalValue,String(decision.value));
  assert.deepEqual(evidence.pages,decision.pages);
  assert.equal(evidence.rule,decision.rule);assert.equal(evidence.rationale,decision.reason);
  assert(evidence.pages.length&&evidence.pages.every(p=>Number.isInteger(p)&&p>=1&&p<=source.pages));
 }else if(evidence.kind==='retained_first_pass_note_not_fresh_adjudication'){
  assert.equal(r.finalValue,original.value);
  assert.equal(evidence.recordedLocator,original.recordedLocator);assert.equal(evidence.rationale,original.rationale);
 }else{
  assert.equal(evidence.kind,'retained_prior_sample_decision');
  assert.equal(evidence.value,r.finalValue);assert(evidence.recordedLocator&&evidence.rationale);
 }
}
assert.equal(studies.size,229);assert.equal(keys.size,1603);assert.equal(panels.size,1603);
assert.deepEqual(kinds,index.evidenceKinds);assert.equal(kinds.active_full_text_adjudication,677);
for(const r of snapshot.records)for(const f of ['CASO_locations','Primary_transition_path','Q1','Q2','Q3','Q4','Q5'])assert(keys.has(r.ID+'|'+f));
console.log(JSON.stringify({status:'PASS',studies:229,fieldRecords:1603,evidenceKinds:kinds,originalPairRecords:1603,scope:'Checks exported values, paired-judgment links, source-file identity and active decision anchors. It does not validate semantic interpretation, revalidate earlier locators, or independently authenticate a retained earlier rationale.'},null,2));
