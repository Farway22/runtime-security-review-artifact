import {fileURLToPath} from 'node:url';
// Enumerate supported-route selection choices without changing sealed records.
import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const portable=true;
const prefix=fileURLToPath(new URL('../data/',import.meta.url));
const sealedFile=prefix+'final_core_statistics_2026-10-12.json';
const casesFile=prefix+'route_selection_cases_2026-10-12.json';
const mappingFile=prefix+'source_index.json';
const sealed=JSON.parse(fs.readFileSync(sealedFile,'utf8').replace(/^\uFEFF/,''));
const specification=JSON.parse(fs.readFileSync(casesFile,'utf8'));
const mapping=JSON.parse(fs.readFileSync(mappingFile,'utf8')).items;
const baseline=sealed.records;
if(!portable){const manifest=JSON.parse(fs.readFileSync('planning/statistics_seal_manifest_2026-10-12.json','utf8'));for(const [p,h] of Object.entries(manifest.sha256))assert.equal(hash(p),h,p);}
const groups=['C_A_only','S_without_O','S_and_O','O_without_S','UND'];
const es=['E1','E2','E3','E4','E5','E6'];
const group=p=>p==='UND'?'UND':p.includes('S')?(p.includes('O')?'S_and_O':'S_without_O'):(p.includes('O')?'O_without_S':'C_A_only');
const cases=specification.cases.map(c=>{
 const r=baseline.find(r=>r.ID===c.ID),m=mapping.find(m=>m.Real_ID===c.ID);assert(r&&m);
 assert.equal(r.core.Primary_transition_path,'UND',c.ID);
 if(!portable)assert.equal(hash(m.source),m.textSha256,'source '+c.ID);
 assert(c.alternatives.length>=2);
 for(const a of c.alternatives)assert(/^[CASO](>[CASO])*$/.test(a.path),a.path);
 return {...c,Title:m.Title,E:r.E,source:m.source,textSha256:m.textSha256};
});
assert.equal(new Set(cases.map(c=>c.ID)).size,cases.length);
function summarize(overrides){
 const paths={},edges={},joint=Object.fromEntries(groups.map(g=>[g,Object.fromEntries(es.map(e=>[e,0]))]));
 for(const r of baseline){const p=overrides[r.ID]??r.core.Primary_transition_path;paths[p]=(paths[p]??0)+1;joint[group(p)][r.E]++;
  if(p!=='UND'){const ns=p.split('>');for(const edge of new Set(ns.slice(1).map((v,i)=>ns[i]+'>'+v)))edges[edge]=(edges[edge]??0)+1;}
 }
 const resolved=Object.entries(paths).filter(([p])=>p!=='UND').sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]));
 const metrics={complete_CA:paths['C>A']??0,edge_CA:edges['C>A']??0,edge_SC:edges['S>C']??0,edge_OC:edges['O>C']??0,UND:paths.UND??0};
 for(const g of groups){const n=es.reduce((s,e)=>s+joint[g][e],0);metrics[g+'_n']=n;metrics[g+'_E5E6_n']=joint[g].E5+joint[g].E6;metrics[g+'_E5E6_percent']=n?100*(joint[g].E5+joint[g].E6)/n:null;metrics[g+'_E3_percent']=n?100*joint[g].E3/n:null;}
 return {metrics,largestResolvedPath:resolved[0],largestEdge:Object.entries(edges).sort((a,b)=>b[1]-a[1])[0],pathCounts:paths,joint};
}
const baselineResult=summarize({});
assert.equal(baselineResult.metrics.complete_CA,96);assert.equal(baselineResult.metrics.UND,76);
const scenarios=[];
function enumerate(i,overrides){if(i===cases.length){scenarios.push({...summarize(overrides),assignments:{...overrides}});return;}for(const a of cases[i].alternatives)enumerate(i+1,{...overrides,[cases[i].ID]:a.path});}
enumerate(0,{});
assert.equal(scenarios.length,cases.reduce((n,c)=>n*c.alternatives.length,1));
for(const s of scenarios){assert.equal(Object.values(s.pathCounts).reduce((a,b)=>a+b,0),229);for(const e of es)assert.equal(groups.reduce((n,g)=>n+s.joint[g][e],0),sealed.statistics.endpoints[e].n);}
const envelope=Object.fromEntries(Object.keys(baselineResult.metrics).map(k=>{
 const sorted=scenarios.filter(s=>s.metrics[k]!==null).sort((a,b)=>a.metrics[k]-b.metrics[k]);
 return [k,{baseline:baselineResult.metrics[k],min:sorted[0].metrics[k],max:sorted.at(-1).metrics[k],minAssignments:sorted[0].assignments,maxAssignments:sorted.at(-1).assignments}];
}));
const result={date:'2026-10-12',status:'PASS',sourceVerification:portable?'Not repeated in portable replay; source full texts are not bundled.':'Original source hashes and sealed workspace inputs checked.',scope:specification.scope,selection:specification.selection,cases,scenarioCount:scenarios.length,unchangedOtherStudies:229-cases.length,baseline:baselineResult,envelope,CACompleteFirstInEveryScenario:scenarios.every(s=>s.largestResolvedPath[0]==='C>A'),CAEdgeFirstInEveryScenario:scenarios.every(s=>s.largestEdge[0]==='C>A'),fixedFields:['Corpus membership','CASO coverage','Endpoint realization','Q1-Q5'],interpretation:'Local supported-route-selection sensitivity only. This does not validate other disputed assignments, test CASO/quality uncertainty, or estimate blind final-rule reproducibility. The sealed unique-primary assignments remain unchanged. No endpoint is newly paired to the scenario-selected mechanism.',inputHashes:{[sealedFile]:hash(sealedFile),[casesFile]:hash(casesFile),[mappingFile]:hash(mappingFile)}};
if(process.argv.includes('--summary')){delete result.cases;delete result.baseline;for(const v of Object.values(result.envelope)){delete v.minAssignments;delete v.maxAssignments;}}
const serialized=JSON.stringify(result,null,2);
if(process.argv.includes('--save')){
 assert(!process.argv.includes('--summary'),'Save complete provenance, not the summary');
 fs.writeFileSync(prefix+'route_selection_results_2026-10-12.json',serialized+'\n');
 console.log(JSON.stringify({status:result.status,scenarioCount:result.scenarioCount,output:prefix+'route_selection_results_2026-10-12.json'}));
}else console.log(serialized);
