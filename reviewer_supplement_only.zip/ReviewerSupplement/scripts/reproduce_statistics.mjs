// Read-only, dependency-free replay of the public study-level dataset and original paired judgments.
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
const root=fileURLToPath(new URL('../',import.meta.url));
const read=p=>fs.readFileSync(path.join(root,p),'utf8').replace(/^\uFEFF/,'');
const json=p=>JSON.parse(read(p));
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(path.join(root,p))).digest('hex');
function table(p){
 const text=read(p),rows=[];let row=[],cell='',quoted=false;
 for(let i=0;i<text.length;i++){
  const c=text[i];if(c==='"'){
   if(quoted&&text[i+1]==='"'){cell+='"';i++;}
   else if(quoted)quoted=false;
   else if(cell===''&&/^"(?:""|[^"\r\n])*"(?:\t|\r?\n|$)/.test(text.slice(i)))quoted=true;
   else cell+='"';
  }
  else if(!quoted&&c==='\t'){row.push(cell);cell='';}
  else if(!quoted&&c==='\n'){row.push(cell.replace(/\r$/,''));rows.push(row);row=[];cell='';}
  else cell+=c;
 }
 if(cell||row.length){row.push(cell.replace(/\r$/,''));rows.push(row);}
 assert(!quoted,p);const headers=rows.shift();
 return rows.filter(r=>r.some(Boolean)).map(r=>{assert.equal(r.length,headers.length,p);return Object.fromEntries(headers.map((h,i)=>[h,r[i]]));});
}
const rows=table('data/final_core229_2026-10-12.tsv');
assert.equal(hash('data/final_core229_2026-10-12.tsv'),'f4242b3e73abdd5f92fa3dd6aeaaf16a37075ef799429d7389e47fb27a027ab7');
assert.equal(rows.length,229);assert.equal(new Set(rows.map(r=>r.ID)).size,229);
const norm=s=>s.toLowerCase().replace(/\s+/g,' ').trim();
assert.equal(new Set(rows.map(r=>norm(r.Title))).size,229);
const snapshot=json('data/final_core_statistics_2026-10-12.json');
const byID=new Map(snapshot.records.map(r=>[r.ID,r]));
const fields=['CASO_locations','Primary_transition_path','Q1','Q2','Q3','Q4','Q5'];
for(const r of rows){
 const s=byID.get(r.ID);assert(s);assert.equal(r.Title,s.Title);
 for(const f of fields)assert.equal(r[f],String(s.core[f]),r.ID+' '+f);
 for(const f of fields.slice(2))assert(['0','0.5','1'].includes(r[f]));
 const total=fields.slice(2).reduce((n,f)=>n+Number(r[f]),0);
 assert.equal(total,Number(r.Total));assert.equal(r.Quality,total>=4?'High':total>=3?'Moderate':'Low');
 assert.equal(total,s.Total);assert.equal(r.Quality,s.Quality);assert.equal(r.E_current,s.E);
 assert(/^[CASO](;[CASO])*$/.test(r.CASO_locations));
 if(r.Primary_transition_path!=='UND'){
  assert(/^[CASO](>[CASO])*$/.test(r.Primary_transition_path));
  assert(r.Primary_transition_path.split('>').every(n=>r.CASO_locations.split(';').includes(n)));
 }
}
const dist=values=>Object.fromEntries([...new Set(values)].sort().map(v=>[v,{n:values.filter(x=>x===v).length,percent:100*values.filter(x=>x===v).length/values.length}]));
const statistics={n:rows.length,quality:dist(rows.map(r=>r.Quality)),endpoints:dist(rows.map(r=>r.E_current)),primaryPaths:dist(rows.map(r=>r.Primary_transition_path)),CASO:Object.fromEntries(['C','A','S','O'].map(c=>[c,{n:rows.filter(r=>r.CASO_locations.split(';').includes(c)).length,percent:100*rows.filter(r=>r.CASO_locations.split(';').includes(c)).length/229}])),pathForms:dist(rows.map(r=>r.Primary_transition_path==='UND'?'UND':r.Primary_transition_path.includes('>')?'directed':'single-node')),qualityCriteria:Object.fromEntries(fields.slice(2).map(f=>[f,dist(rows.map(r=>r[f]))]))};
statistics.adjacentEdges={};
const family=p=>p==='UND'?'UND':p.includes('S')?(p.includes('O')?'S_and_O':'S_without_O'):(p.includes('O')?'O_without_S':'C_A_only');
const families=['C_A_only','S_without_O','S_and_O','O_without_S','UND'];
const joint=Object.fromEntries(families.map(f=>[f,Object.fromEntries(['E1','E2','E3','E4','E5','E6'].map(e=>[e,0]))]));
for(const r of rows){
 joint[family(r.Primary_transition_path)][r.E_current]++;
 if(r.Primary_transition_path==='UND')continue;
 const n=r.Primary_transition_path.split('>');
 for(const e of new Set(n.slice(1).map((x,i)=>n[i]+'>'+x)))statistics.adjacentEdges[e]=(statistics.adjacentEdges[e]??0)+1;
}
for(const [k,v] of Object.entries(statistics))assert.deepEqual(v,snapshot.statistics[k],k);
assert.deepEqual(Object.values(statistics.endpoints).map(x=>x.n),[4,9,99,68,48,1]);
assert.equal(statistics.primaryPaths['C>A'].n,96);assert.equal(statistics.adjacentEdges['C>A'],120);
assert.equal(statistics.pathForms.directed.n,148);assert.equal(statistics.pathForms['single-node'].n,5);assert.equal(statistics.pathForms.UND.n,76);
function agreement(pairs,levels=null){
 const categories=levels??[...new Set(pairs.flat())],n=pairs.length;
 const distance=(a,b)=>levels?Math.abs(categories.indexOf(a)-categories.indexOf(b))/(categories.length-1):Number(a!==b);
 const exact=pairs.filter(([a,b])=>a===b).length;
 const observed=pairs.reduce((s,[a,b])=>s+distance(a,b),0)/n;
 let expected=0;for(const a of categories)for(const b of categories)expected+=pairs.filter(p=>p[0]===a).length*pairs.filter(p=>p[1]===b).length*distance(a,b)/(n*n);
 return {n,exact,percent:100*exact/n,kappa:expected===0?null:1-observed/expected};
}
const reliability={};
for(const panel of ['original37','new192']){
 const original=snapshot.reliability[panel];reliability[panel]={n:original.n,metrics:{}};
 for(const f of fields){
  const pairs=original.paired[f],result=agreement(pairs,f.startsWith('Q')?['0','0.5','1']:null),reference=original.metrics[f];
  if(f==='CASO_locations'){
   const valid=pairs.filter(p=>!p.includes('UND'));
   result.jaccardMean=valid.reduce((s,[a,b])=>{const A=new Set(a.split(';')),B=new Set(b.split(';'));return s+[...A].filter(x=>B.has(x)).length/new Set([...A,...B]).size;},0)/valid.length;
   result.jaccardN=valid.length;delete result.kappa;
  }
  for(const [k,v] of Object.entries(result))assert.equal(v,reference[k],panel+' '+f+' '+k);
  reliability[panel].metrics[f]=result;
 }
}
const selection=snapshot.selectionReliability;
assert.equal(selection.status,'verified_from_original_paired_decisions');
const selectionAgreement=agreement(selection.pairs.map(p=>[p.first,p.second]));
for(const [k,v] of Object.entries(selectionAgreement))assert.equal(v,selection[k],'selection '+k);
const candidates=table('search/supplementary_candidate_archive.tsv'),earlier=table('search/earlier_eligibility_decisions.tsv'),update=table('search/final_update_inclusion_decisions.tsv');
const earlierByTitle=new Map(earlier.map(r=>[norm(r.Title),r]));
const candidateTitles=new Set([...candidates.map(r=>norm(r.title)),...update.map(r=>norm(r.title))]);
assert.equal(candidateTitles.size,268);assert.equal(earlier.length,88);assert.equal(update.length,166);
const selectedEarlier=earlier.filter(r=>r.Final_decision==='Include-primary');
const selectedUpdate=update.filter(r=>r.final_decision==='Include-primary'||r.final_decision==='Include');
const finalSelected=new Set([...selectedEarlier.map(r=>norm(r.Title)),...selectedUpdate.map(r=>norm(r.title))]);
assert.equal(selectedEarlier.length,74);assert.equal(selectedUpdate.length,155);
assert.deepEqual([...finalSelected].sort(),rows.map(r=>norm(r.Title)).sort(),'final selected titles');
const search={candidateReports:candidateTitles.size,earlierFullText:earlier.length,additionalFullText:update.length,totalFullText:earlier.length+update.length,finalPrimary:finalSelected.size,earlierPrimary:selectedEarlier.length,additionalPrimary:selectedUpdate.length,initialHistoricalExclusions:candidates.filter(r=>!earlierByTitle.has(norm(r.title))).length,earlierDecisions:dist(earlier.map(r=>r.Final_decision)),updateDecisions:dist(update.map(r=>r.final_decision)),arxivTriageRecords:table('search/arxiv_all_record_triage.tsv').length};
assert.equal(search.arxivTriageRecords,1562);
search.arxivDeduplicatedRecords=table('search/arxiv_deduplicated_screening_set.tsv').length;
assert.equal(search.arxivDeduplicatedRecords,1597);
const decisions=json('data/core_field_adjudication.json');
assert.equal(decisions.decisions.length,677);assert.equal(new Set(decisions.decisions.map(d=>d.ID+'|'+d.field)).size,677);
for(const d of decisions.decisions){assert.equal(String(byID.get(d.ID).core[d.field]),String(d.value),d.ID+' adjudication');assert(d.pages.length);}
const sources=json('data/source_index.json').items;
assert.equal(sources.length,229);assert.deepEqual(sources.map(s=>s.Real_ID).sort(),rows.map(r=>r.ID).sort());
const extraction=table('data/descriptive_extraction229.tsv');
assert.equal(extraction.length,229);assert.deepEqual(extraction.map(r=>r.ID).sort(),rows.map(r=>r.ID).sort());
if(fs.existsSync(path.join(root,'manifest.json'))){
 const manifest=json('manifest.json');
 for(const [p,expected] of Object.entries(manifest.sha256))assert.equal(hash(p),expected,p+' manifest');
}
console.log(JSON.stringify({status:'PASS',checks:['final TSV identity and unique membership','TSV/snapshot equality','quality recalculation','endpoint and CASO distributions','paths and adjacent edges','original paired agreement','final selection membership','active decision values','source and descriptive-extraction coverage','manifest hashes when present'],statistics,jointPathEndpoints:joint,reliability,selectionAgreement,search,activeCoreDecisions:677,limitations:'Public replay checks packaged values and calculations, not semantic coding accuracy, original experiments, or new blind repeatability under final rules.'},null,2));
