import {fileURLToPath} from 'node:url';
// Conservative, fieldwise stress tests of archived disagreements. Never recode the seal.
import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
const portable=true,prefix=fileURLToPath(new URL('../data/',import.meta.url));
const read=p=>fs.readFileSync(p,'utf8').replace(/^\uFEFF/,'');
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const sealedFile=prefix+'final_core_statistics_2026-10-12.json';
const diagnosticFile=prefix+'recorded_disagreement_input_2026-10-12.json';
const mappingFile=prefix+'source_index.json';
const sealed=JSON.parse(read(sealedFile));
const diagnostic=portable?JSON.parse(read(diagnosticFile)):JSON.parse(execFileSync(process.execPath,['planning/analyze_coding_sensitivity_joint_2026-10-12.mjs'],{encoding:'utf8',maxBuffer:32*1024*1024}));
const diagnosticSerialized=JSON.stringify(diagnostic,null,2)+'\n';
if(!portable&&process.argv.includes('--save'))fs.writeFileSync(diagnosticFile,diagnosticSerialized);
if(!portable){assert(fs.existsSync(diagnosticFile),'Generate the input snapshot with --save first');assert.equal(hash(diagnosticFile),crypto.createHash('sha256').update(diagnosticSerialized).digest('hex'),'Current diagnostic must match the dedicated input snapshot');}
const mapping=JSON.parse(read(mappingFile)).items,rows=sealed.records;
assert.equal(rows.length,229);assert.equal(new Set(rows.map(r=>r.ID)).size,229);
if(!portable){
 const manifest=JSON.parse(read('planning/statistics_seal_manifest_2026-10-12.json'));
 for(const [p,h] of Object.entries(manifest.sha256))assert.equal(hash(p),h,p);
}
const groups=['C_A_only','S_without_O','S_and_O','O_without_S','UND'];
const family=p=>p==='UND'?'UND':p.includes('S')?(p.includes('O')?'S_and_O':'S_without_O'):(p.includes('O')?'O_without_S':'C_A_only');
const casesFor=field=>diagnostic.differences.filter(d=>d.field===field).map(d=>{
 const r=rows.find(r=>r.ID===d.ID),m=mapping.find(m=>m.Real_ID===d.ID);assert(r&&m);
 assert.equal(r.core[field],d.reconciled);assert.notEqual(d.historical,d.independent);
 assert(d.coordinatorDecision||d.priorSampleDecision,'Traceable adjudication required');
 const options=[...new Set([d.historical,d.independent,d.reconciled])];
 for(const p of options)assert(field==='Primary_transition_path'?p==='UND'||/^[CASO](>[CASO])*$/.test(p):/^[CASO](;[CASO])*$/.test(p),'Invalid normalized label '+p);
 if(!portable)assert.equal(hash(m.source),m.textSha256,'Source continuity '+d.ID);
 return {...d,options,source:m.source,textSha256:m.textSha256};
});
const pathCases=casesFor('Primary_transition_path'),casoCases=casesFor('CASO_locations');
assert.equal(pathCases.length,120);assert.equal(casoCases.length,199);
for(const cases of [pathCases,casoCases])assert.equal(new Set(cases.map(c=>c.ID)).size,cases.length);
const pathOptions=new Map(pathCases.map(c=>[c.ID,c.options]));
const optionsFor=r=>pathOptions.get(r.ID)??[r.core.Primary_transition_path];
// Every count is additive. Each record independently chooses the option attaining its bound.
function bound(score){
 let baseline=0,min=0,max=0;const minAssignments={},maxAssignments={};
 for(const r of rows){baseline+=score(r.core.Primary_transition_path,r);const choices=optionsFor(r).map(p=>({p,v:score(p,r)})).sort((a,b)=>a.v-b.v);min+=choices[0].v;max+=choices.at(-1).v;if(pathOptions.has(r.ID)){minAssignments[r.ID]=choices[0].p;maxAssignments[r.ID]=choices.at(-1).p;}}
 return {baseline,min,max,minAssignments,maxAssignments};
}
const allPaths=[...new Set(rows.flatMap(optionsFor))].sort();
const completePaths=Object.fromEntries(allPaths.map(p=>[p,bound(x=>Number(x===p))]));
const edgeSet=p=>{if(p==='UND')return new Set();const n=p.split('>');return new Set(n.slice(1).map((v,i)=>n[i]+'>'+v));};
const allEdges=[...new Set(allPaths.flatMap(p=>[...edgeSet(p)]))].sort();
const adjacentEdges=Object.fromEntries(allEdges.map(e=>[e,bound(p=>Number(edgeSet(p).has(e)))]));
const pathMargins=Object.fromEntries(allPaths.filter(p=>p!=='C>A'&&p!=='UND').map(p=>[p,bound(x=>Number(x==='C>A')-Number(x===p))]));
const edgeMargins=Object.fromEntries(allEdges.filter(e=>e!=='C>A').map(e=>[e,bound(p=>Number(edgeSet(p).has('C>A'))-Number(edgeSet(p).has(e)))]));
// Exact group ratios: forced members are fixed; optional low-endpoint members minimize
// E5/E6 share, optional high-endpoint members maximize it. Endpoints themselves are fixed.
const familyBounds=Object.fromEntries(groups.map(g=>{
 let forcedN=0,forcedK=0,optionalHigh=0,optionalLow=0;
 const minAssignments={},maxAssignments={};
 for(const r of rows){const options=optionsFor(r),inside=options.filter(p=>family(p)===g),outside=options.filter(p=>family(p)!==g);const high=['E5','E6'].includes(r.E);
  if(inside.length&&!outside.length){forcedN++;forcedK+=Number(high);}
  if(inside.length&&outside.length){if(high)optionalHigh++;else optionalLow++;}
  if(pathOptions.has(r.ID)){minAssignments[r.ID]=inside.length&&!outside.length?inside[0]:inside.length?(high?outside[0]:inside[0]):outside[0];maxAssignments[r.ID]=inside.length&&!outside.length?inside[0]:inside.length?(high?inside[0]:outside[0]):outside[0];}
 }
 if(forcedN+optionalLow===0){const r=rows.find(r=>optionsFor(r).some(p=>family(p)===g));assert(r,'Group must be attainable');minAssignments[r.ID]=optionsFor(r).find(p=>family(p)===g);}
 if(forcedN+optionalHigh===0){const r=rows.find(r=>optionsFor(r).some(p=>family(p)===g));assert(r,'Group must be attainable');maxAssignments[r.ID]=optionsFor(r).find(p=>family(p)===g);}
 const baselineRows=rows.filter(r=>family(r.core.Primary_transition_path)===g);
 const ratio={baseline:100*baselineRows.filter(r=>['E5','E6'].includes(r.E)).length/baselineRows.length,min:forcedN+optionalLow?100*forcedK/(forcedN+optionalLow):100,max:forcedN+optionalHigh?100*(forcedK+optionalHigh)/(forcedN+optionalHigh):0,nonemptyGroupOnly:true,minAssignments,maxAssignments};
 return[g,{n:bound(p=>Number(family(p)===g)),E5E6Count:bound((p,r)=>Number(family(p)===g&&['E5','E6'].includes(r.E))),E5E6Percent:ratio,forcedN,forcedK,optionalHigh,optionalLow}];
}));
// Replay every ratio witness to verify the closed-form solution.
for(const [g,v] of Object.entries(familyBounds))for(const end of ['min','max']){const assignments=v.E5E6Percent[end+'Assignments'];const members=rows.filter(r=>family(assignments[r.ID]??r.core.Primary_transition_path)===g);const observed=100*members.filter(r=>['E5','E6'].includes(r.E)).length/members.length;assert.equal(observed,v.E5E6Percent[end]);}
const casoOptions=new Map(casoCases.map(c=>[c.ID,c.options]));
const casoCoverage=Object.fromEntries(['C','A','S','O'].map(k=>{let baseline=0,min=0,max=0;const minAssignments={},maxAssignments={};for(const r of rows){baseline+=Number(r.core.CASO_locations.split(';').includes(k));const choices=(casoOptions.get(r.ID)??[r.core.CASO_locations]).map(p=>({p,v:Number(p.split(';').includes(k))})).sort((a,b)=>a.v-b.v);min+=choices[0].v;max+=choices.at(-1).v;if(casoOptions.has(r.ID)){minAssignments[r.ID]=choices[0].p;maxAssignments[r.ID]=choices.at(-1).p;}}return[k,{baseline,min,max,minAssignments,maxAssignments}];}));
const challengedCA=pathCases.filter(c=>c.reconciled==='C>A').map(c=>({ID:c.ID,Title:c.Title,options:c.options,decision:c.coordinatorDecision??c.priorSampleDecision}));
assert.equal(challengedCA.length,7);assert.deepEqual([completePaths['C>A'].min,completePaths['C>A'].max],[89,176]);
const simplify=b=>Object.fromEntries(Object.entries(b).filter(([k])=>!k.endsWith('Assignments')));
const result={date:'2026-10-12',status:'PASS',scope:'Conservative recorded-label stress tests, not a new semantic review, independent final-rule coding, or replacement of adjudication.',design:'At every original first-pass disagreement, allow the historical, independent and adjudicated normalized labels. Keep agreement records at final values. Includes labels rejected by adjudication; options are not endorsed as equally valid. Choices may mix rule versions, so the stress space does not represent one coherently recoded corpus. Path and CASO tests are separate, not joint.',pathDisagreements:pathCases.length,casoDisagreements:casoCases.length,pathPanels:{original37:pathCases.filter(c=>c.panel==='original37').length,new192:pathCases.filter(c=>c.panel==='new192').length},unchangedPathRecords:229-pathCases.length,unchangedCASORecords:229-casoCases.length,pathCases,casoCases,challengedCA,completePaths,adjacentEdges,pathMargins,edgeMargins,familyBounds,casoCoverage,CACompleteFirstForEveryAllowedAssignment:Object.values(pathMargins).every(v=>v.min>0),CAEdgeFirstForEveryAllowedAssignment:Object.values(edgeMargins).every(v=>v.min>0),minimumCompletePathLead:Math.min(...Object.values(pathMargins).map(v=>v.min)),minimumEdgeLead:Math.min(...Object.values(edgeMargins).map(v=>v.min)),fixedFields:['Study membership','E1-E6 endpoint values','Q1-Q5'],sourceVerification:portable?'Numerical replay only; original sources/ledgers unavailable.':'Sealed inputs and archived diagnostics replayed against ledgers/submissions; source text hashes checked for continuity, not fresh semantic validation.',limitations:'Addresses recorded first-pass disagreements only. Agreement records and uncertainties not represented by archived labels remain outside the stress space. Bounds are attainable stress envelopes, not confidence intervals, probabilities, or evidence that rejected labels satisfy final rules.',inputHashes:{[sealedFile]:hash(sealedFile),[diagnosticFile]:hash(diagnosticFile),[mappingFile]:hash(mappingFile)}};
if(process.argv.includes('--summary')){
 delete result.pathCases;delete result.casoCases;
 for(const key of ['completePaths','adjacentEdges','pathMargins','edgeMargins','casoCoverage'])result[key]=Object.fromEntries(Object.entries(result[key]).map(([k,v])=>[k,simplify(v)]));
 for(const v of Object.values(result.familyBounds))for(const key of ['n','E5E6Count','E5E6Percent'])v[key]=simplify(v[key]);
}
const serialized=JSON.stringify(result,null,2);
if(process.argv.includes('--save')){assert(!process.argv.includes('--summary'),'Save complete witnesses and provenance');const output=prefix+'recorded_disagreement_results_2026-10-12.json';fs.writeFileSync(output,serialized+'\n');console.log(JSON.stringify({status:result.status,output,pathDisagreements:result.pathDisagreements,casoDisagreements:result.casoDisagreements}));}
else console.log(serialized);
