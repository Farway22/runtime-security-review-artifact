# Literature Search Protocol v1

## Status

- Search date: 2026-07-27
- Publication cutoff: 2026-06-30
- Coverage window: 2022-01-01 to 2026-06-30
- Purpose: construct a review corpus for a runtime-oriented review of security threats in autonomous LLM agents.
- Current stage: candidate retrieval and first-pass relevance screening. This file must not yet be described as a completed PRISMA review.

## Review Questions

- RQ1: Which runtime stages of autonomous LLM agents are covered by existing security research?
- RQ2: Under which preconditions and mechanisms do attacks propagate between runtime stages?
- RQ3: At which transitions do existing defenses interrupt, constrain, or fail to interrupt an attack?
- RQ4: Which runtime stages, evaluation horizons, frameworks, and evidence types remain under-studied?

## Scope

The review focuses on LLM-based agents that can perform at least one of the following: invoke tools, interact with an environment, maintain memory or workspace state, execute multi-step workflows, or communicate with other agents. Pure text-generation safety studies are included only when their attack or defense is evaluated in an agentic or tool-integrated setting.

The operational runtime stages are:

- C - Context assembly: model-visible instructions, retrieved content, tool feedback, and other runtime context.
- A - Tool and action: tool selection, arguments, authorization, invocation, and action execution.
- S - State and persistence: memory, RAG stores, workspaces, sessions, and configuration that survive a reasoning step or session.
- O - Orchestration and automation: triggers, schedules, retries, multi-agent routing, and cross-service propagation.

Multi-label coding is allowed. For example, poisoning a RAG store is S, retrieval is A, and consumption of the retrieved text is C.

## Sources Used in Phase 1

- arXiv official API, for broad and recent preprint retrieval.
- ACL Anthology, ICLR/OpenReview, NeurIPS proceedings, PMLR, CVF Open Access, ACM/ICSE records, and IEEE publication metadata, for publication-status verification.
- Official framework and standard sources for MITRE ATLAS, OWASP Agentic Security, CSA MAESTRO, and AI Exchange.
- Backward and forward snowballing from AgentDojo, ASB, ToolEmu, InjecAgent, AgentPoison, and the surveys named by the reviewers.

Scopus, Web of Science, and IEEE Xplore query exports should be added in Phase 2 through institutional access. Their record counts must be preserved before a PRISMA flow is reported.

## Search Strings

### Broad query

```text
("large language model" OR LLM OR "generative AI")
AND
(agent OR agentic OR "autonomous agent" OR "tool-using agent")
AND
(security OR attack OR threat OR vulnerability OR defense
 OR injection OR poisoning OR jailbreak)
```

### Runtime-stage queries

```text
(LLM OR "large language model") AND agent
AND ("prompt injection" OR "indirect prompt injection" OR "context poisoning")

(LLM OR "large language model") AND agent
AND (tool OR "function calling" OR MCP OR "Model Context Protocol")
AND (security OR attack OR defense OR privilege OR authorization)

(LLM OR "large language model") AND agent
AND (memory OR RAG OR workspace OR persistence)
AND (security OR poisoning OR extraction OR privacy OR attack)

(LLM OR "large language model") AND (agent OR "multi-agent")
AND (security OR attack OR defense OR communication OR supply-chain
 OR automation OR orchestration)
```

## Inclusion Criteria

- Published between 2022-01-01 and 2026-06-30.
- Studies an LLM-based agent, tool-integrated LLM application, computer-use agent, or LLM multi-agent system.
- Contains an explicit security/safety threat, attack, defense, benchmark, formal model, or empirical security evaluation.
- Provides enough methodological detail to identify the affected runtime stage and evidence basis.
- English-language full text is available.

## Exclusion Criteria

- Pure LLM jailbreak, toxicity, or alignment work with no agentic evaluation or runtime implication.
- Work using LLM agents only to perform cybersecurity tasks, unless it evaluates risks created by the agent itself.
- Conventional multi-agent reinforcement learning with no LLM-based agent component.
- Position pieces, vendor blogs, and community posts used as primary evidence.
- Duplicate preprint and conference versions; retain the peer-reviewed version and record the arXiv identifier as a secondary link.
- Papers published after 2026-06-30.

## Evidence Coding

Each retained item should be coded using the following fields:

```text
ID
Title
Year
Authors
Publication status
Venue or repository
DOI or persistent URL
Study type: attack / defense / benchmark / survey / formalization
Runtime stages: C / A / S / O
Threat source
Attacker capability
Empirical basis
Evaluated framework or environment
Evaluation horizon: single-turn / multi-step / cross-session / unspecified
Metrics
MITRE ATLAS alignment
OWASP alignment
MAESTRO alignment
Include / exclude / background-only
Exclusion reason
```

## Evidence Quality

- High: peer-reviewed full paper with empirical evaluation, reproducible benchmark, or formal guarantees.
- Medium: technically detailed preprint with experiments, artifacts, or code.
- Low: conceptual preprint, framework documentation, standard, community report, or unreplicated incident account.

Standards and official documentation may be authoritative for terminology and mappings while remaining non-empirical evidence. Evidence quality and source authority should therefore be reported separately.

## Screening Procedure

1. Deduplicate by DOI, arXiv ID, and normalized title.
2. Screen title and abstract against the scope and inclusion criteria.
3. Retrieve full text for all potentially relevant studies.
4. Apply inclusion and exclusion criteria at full-text level and record one primary exclusion reason.
5. Code retained studies with multi-label runtime stages.
6. Have a second author independently code at least 20% of the corpus.
7. Report agreement using Cohen's kappa for layer assignment and study type.
8. Resolve disagreements by discussion and document rule changes.

## Reporting Rules

- Do not call the review systematic until Phase 2 database exports and full-text screening are complete.
- Report peer-reviewed studies, preprints, standards, and framework documentation separately.
- Do not add multi-label layer counts as though they were mutually exclusive.
- Do not infer research imbalance from a hand-picked representative table; compute it from the complete retained corpus.
- Keep the complete evidence matrix in an appendix or supplementary file and use a compact representative table in the paper.
