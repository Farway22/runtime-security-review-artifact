# Search and selection records

The manuscript presents one reconciled selection workflow. The files here preserve source records with their actual scopes; intermediate labels must not be used as final corpus membership.

## Current membership and reproducible reconciliation

The union of the 102 records in `supplementary_candidate_archive.tsv` and 166 update candidates in `final_update_inclusion_decisions.tsv` contains **268 unique candidate titles**. Fourteen historical candidates do not enter the earlier full-text pool, leaving **254 assessed reports** (88 earlier reports plus 166 update reports). Final decisions retain **229 primary studies**, **24 background reports**, and exclude one full-text report. The public statistics script checks that the selected 74+155 titles exactly match the final 229-study dataset.

These subsets identify the source of retained records, not separate synthesis cohorts. Only the final dataset supplies quantitative core coding.

## Executed broad retrieval

`arxiv_search_manifest.json` records the executed query, submitted-date window and retrieval counts. `run_arxiv_update_search.ps1` preserves the original API query implementation. The recorded execution returned 1,671 records; broad-text filtering and title deduplication retained 1,597. Repeating a live API query later may return different metadata or counts; the deposited records identify this execution.

- `arxiv_deduplicated_screening_set.tsv`: all **1,597** retained metadata records, including **35** matches to the existing corpus.
- `arxiv_all_record_triage.tsv`: **1,562** remaining records after those existing-corpus matches were separated; broad triage labels are not final eligibility decisions.
- `arxiv_title_abstract_screening_decisions.tsv`: the **97-record manual high-sensitivity queue**, not the entire 1,597-record set. Boundary review and existing candidates also fed full-text retrieval.
- `arxiv_fulltext_screening_decisions.tsv`: the **166-report intermediate full-text decisions** (162 Include, four Background), with rationale and evidence pages.
- `final_update_inclusion_decisions.tsv`: the **final decisions for those 166 reports** (155 Include, ten Background, one Exclude). These supersede the intermediate membership labels. Old quality scores are intentionally not copied; use the final core dataset.

Raw API XML pages and every venue-index search result are not deposited here. The manifest and retained-record tables support inspection of the executed arXiv retrieval and final reconciliation; they are not claimed to be a complete raw export of every supplementary source. Abstracts and source full texts are not redistributed.

## Supplementary retrieval and snowballing provenance

- `supplementary_candidate_archive.tsv`: **102** historical candidate records, persistent sources, provenance and archival screening labels; 74 originated in direct supplementary retrieval and 28 in snowballing. Not all candidates became primary studies.
- `earlier_eligibility_decisions.tsv`: final eligibility for the earlier **88** assessed reports (74 primary, 14 background), with page evidence. Historical quality scores are omitted.
- `archived_snowballing_protocol_and_log.md`: backward/forward seeds and iteration-specific records. The 28 added candidates comprise 15 backward and ten forward additions, then two and one additions in later rounds; the final iteration added no new in-scope candidate.
- `archived_search_protocol_v1.md`: an archival discovery protocol, **not the current RQs or final eligibility specification**. Its earlier study organization and planned vocabulary must not be read as a record that every listed query was executed.

The current eligibility criteria, agentic/RAG boundary, publication-version policy and synthesis populations are specified in the manuscript and `methods/methodology_coding_details.md`. Archived filenames/dates support traceability and do not introduce separate main-text research populations.
