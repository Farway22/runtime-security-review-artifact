$ErrorActionPreference = 'Stop'

$OutputDirectory = $PSScriptRoot
$RawDirectory = Join-Path $OutputDirectory 'raw'
New-Item -ItemType Directory -Force -Path $RawDirectory | Out-Null

$SearchDate = '2026-09-08'
$PublicationStart = [datetime]'2022-01-01T00:00:00Z'
$PublicationCutoff = [datetime]'2026-06-30T23:59:59Z'
$Query = 'all:"large language model" AND (all:agent OR all:agentic) AND (all:security OR all:attack OR all:defense OR all:injection OR all:poisoning OR all:vulnerability OR all:threat) AND submittedDate:[202201010000 TO 202606302359]'
$PageSize = 100
$UserAgent = 'agent-security-systematic-review/1.0 (literature update search)'

function Get-ArxivPage {
    param([int]$Start)

    $encoded = [uri]::EscapeDataString($Query)
    $uri = "https://export.arxiv.org/api/query?search_query=$encoded&start=$Start&max_results=$PageSize&sortBy=submittedDate&sortOrder=ascending"
    for ($attempt = 1; $attempt -le 5; $attempt++) {
        try {
            $response = Invoke-WebRequest -Uri $uri -Headers @{ 'User-Agent' = $UserAgent } -TimeoutSec 45
            return [xml]$response.Content
        }
        catch {
            if ($attempt -eq 5) { throw }
            Start-Sleep -Seconds (8 * $attempt)
        }
    }
}

$firstPage = Get-ArxivPage -Start 0
$ns = [System.Xml.XmlNamespaceManager]::new($firstPage.NameTable)
$ns.AddNamespace('atom', 'http://www.w3.org/2005/Atom')
$ns.AddNamespace('os', 'http://a9.com/-/spec/opensearch/1.1/')
$total = [int]$firstPage.SelectSingleNode('//os:totalResults', $ns).InnerText

$records = [System.Collections.Generic.List[object]]::new()
$rawPages = [System.Collections.Generic.List[string]]::new()

for ($start = 0; $start -lt $total; $start += $PageSize) {
    Write-Host ("Retrieving arXiv records {0}-{1} of {2}" -f ($start + 1), [math]::Min($start + $PageSize, $total), $total)
    $page = if ($start -eq 0) { $firstPage } else { Get-ArxivPage -Start $start }
    $rawPath = Join-Path $RawDirectory ("arxiv_{0:D5}.xml" -f $start)
    $page.Save($rawPath)
    $rawPages.Add($rawPath)

    $pageNs = [System.Xml.XmlNamespaceManager]::new($page.NameTable)
    $pageNs.AddNamespace('atom', 'http://www.w3.org/2005/Atom')
    foreach ($entry in $page.SelectNodes('//atom:entry', $pageNs)) {
        $id = [string]$entry.id
        $arxivId = ($id -replace '^https?://arxiv.org/abs/', '') -replace 'v\d+$', ''
        $title = ([string]$entry.title -replace '\s+', ' ').Trim()
        $abstract = ([string]$entry.summary -replace '\s+', ' ').Trim()
        $published = [datetime]$entry.published
        $updated = [datetime]$entry.updated
        $doi = ''
        foreach ($child in $entry.ChildNodes) {
            if ($child.LocalName -eq 'doi') { $doi = [string]$child.InnerText }
        }
        $records.Add([pscustomobject]@{
            source = 'arXiv API'
            arxiv_id = $arxivId
            doi = $doi
            title = $title
            published = $published.ToString('yyyy-MM-dd')
            updated = $updated.ToString('yyyy-MM-dd')
            url = $id
            abstract = $abstract
        })
    }
    if ($start + $PageSize -lt $total) { Start-Sleep -Seconds 4 }
}

$withinCutoff = @($records | Where-Object {
    ([datetime]$_.published) -ge $PublicationStart -and ([datetime]$_.published) -le $PublicationCutoff
})

$agentPattern = '(?i)\bagent(?:ic|s)?\b|tool[- ](?:use|using|integrated)|multi[- ]agent|computer[- ]use|web agent|robot(?:ic|ics)? agent|model context protocol|\bMCP\b|memory|workspace|retrieval[- ]augmented|\bRAG\b'
$securityPattern = '(?i)security|attack|defen[cs]e|threat|vulnerab|inject|poison|backdoor|jailbreak|unsafe|safety|privacy|exfiltrat|hijack|malicious|risk|guardrail|safeguard'

$screeningSet = @($withinCutoff | Where-Object {
    $text = "$($_.title) $($_.abstract)"
    $text -match $agentPattern -and $text -match $securityPattern
})

function Normalize-Title([string]$Title) {
    return (($Title.ToLowerInvariant() -replace '[^a-z0-9]+', ' ') -replace '\s+', ' ').Trim()
}

$masterPath = Join-Path (Split-Path $PSScriptRoot -Parent) 'recovered_data\candidate_master_recovered.tsv'
$master = Import-Csv -Delimiter "`t" -Path $masterPath
$existingTitles = @{}
foreach ($item in $master) { $existingTitles[(Normalize-Title $item.title)] = $item.id }

$deduplicated = @($screeningSet | Group-Object { Normalize-Title $_.title } | ForEach-Object { $_.Group[0] })
$comparison = foreach ($item in $deduplicated) {
    $normalized = Normalize-Title $item.title
    $existingId = if ($existingTitles.ContainsKey($normalized)) { $existingTitles[$normalized] } else { '' }
    [pscustomobject]@{
        arxiv_id = $item.arxiv_id
        title = $item.title
        published = $item.published
        doi = $item.doi
        url = $item.url
        existing_corpus_id = $existingId
        status = if ($existingId) { 'Existing corpus match' } else { 'Update candidate for title/abstract review' }
        abstract = $item.abstract
    }
}

$newCandidates = @($comparison | Where-Object status -eq 'Update candidate for title/abstract review')
$records | ConvertTo-Json -Depth 4 | Set-Content -Encoding utf8 (Join-Path $RawDirectory 'arxiv_all_records.json')
$comparison | Export-Csv -Delimiter "`t" -NoTypeInformation -Encoding utf8 (Join-Path $OutputDirectory 'arxiv_deduplicated_screening_set.tsv')
$newCandidates | Export-Csv -Delimiter "`t" -NoTypeInformation -Encoding utf8 (Join-Path $OutputDirectory 'arxiv_new_candidates.tsv')

$counts = @(
    [pscustomobject]@{ stage = 'arXiv API records returned by frozen query'; count = $total }
    [pscustomobject]@{ stage = 'Records within publication window'; count = $withinCutoff.Count }
    [pscustomobject]@{ stage = 'Records passing reproducible agent/security text filter'; count = $screeningSet.Count }
    [pscustomobject]@{ stage = 'Deduplicated arXiv screening records'; count = $deduplicated.Count }
    [pscustomobject]@{ stage = 'Exact normalized-title matches in existing 102-record pool'; count = @($comparison | Where-Object existing_corpus_id).Count }
    [pscustomobject]@{ stage = 'Update candidates requiring title/abstract decision'; count = $newCandidates.Count }
)
$counts | Export-Csv -Delimiter "`t" -NoTypeInformation -Encoding utf8 (Join-Path $OutputDirectory 'source_counts.tsv')

$manifest = [ordered]@{
    search_date = $SearchDate
    publication_window = '2022-01-01 to 2026-06-30'
    source = 'arXiv official API'
    query = $Query
    raw_total = $total
    retrieved_records = $records.Count
    raw_pages = $rawPages.Count
    within_cutoff = $withinCutoff.Count
    filtered_screening_set = $screeningSet.Count
    deduplicated_screening_set = $deduplicated.Count
    existing_title_matches = @($comparison | Where-Object existing_corpus_id).Count
    new_candidates = $newCandidates.Count
}
$manifest | ConvertTo-Json | Set-Content -Encoding utf8 (Join-Path $OutputDirectory 'search_manifest.json')

$counts | Format-Table -AutoSize
