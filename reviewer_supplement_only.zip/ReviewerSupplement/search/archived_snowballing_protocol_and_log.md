# Forward and Backward Snowballing Protocol and Log

## Scope and stopping rule

- Review topic: security attacks and defenses for autonomous LLM-agent frameworks.
- Coverage cutoff: 2026-06-30 (inclusive).
- Included evidence: primary empirical, benchmark, defense, measurement, or formalization studies that concern security of an agent, its tools/actions, persistent state, or multi-agent/orchestration environment. Closely related secondary studies are retained separately.
- Excluded evidence: work that merely uses an LLM agent for a cybersecurity task; standalone chatbot safety without an agent-relevant manifestation; non-scholarly commentary; superseded duplicates; and publications after the cutoff.
- Operational saturation: stop after a completed round produces no previously unseen in-scope record after title/abstract screening and deduplication.

## Seed selection

Seeds were selected to cover all four manuscript layers and both attacks and defenses. Review papers were used only as discovery hubs, not as primary evidence.

### Backward seeds (full-text reference lists)

| Seed | Short name | Main coverage |
|---|---|---|
| P01 | Greshake et al. indirect prompt injection | Context to action attack |
| P02 | ToolEmu | Tool/action risk benchmark |
| P03 | InjecAgent | Indirect injection benchmark |
| P04 | AgentDojo | Dynamic attack/defense benchmark |
| P07 | AgentPoison | Persistent memory/knowledge poisoning |
| P11 | Agent Security Bench | Cross-layer benchmark |
| P16 | GuardAgent | Runtime defense |
| P19 | Red-Teaming LLM Multi-Agent Systems | Communication attacks |
| P27 | MINJA | Query-only memory injection |
| P31 | AgentSpec | Runtime policy enforcement |
| S02 | Survey on Trustworthy LLM Agents | Broad discovery hub |
| S06 | SoK: Attack Surface of Agentic AI | Recent discovery hub |

The extracted reference text is stored under `tmp/pdfs/snowball/references/`. PDF layouts did not expose every bibliography as a reliably separable record, so the backward-search denominator is not reported as a PRISMA count at this stage. Every retained record below was nevertheless verified by exact title against an official proceedings page, DOI landing page, OpenReview, or arXiv.

### Forward seeds (DOI-indexed)

Seventeen peer-reviewed seeds with stable DOIs were queried: P01, P03, P05, P06, P09, P10, P12-P14, P18-P23, P31, and P32. OpenCitations Index supplied citing DOIs and OpenCitations Meta supplied title, date, venue, and type metadata. Non-DOI seeds were followed by exact-title searches against official publisher/proceedings pages.

## Procedure

1. Extract the reference section of each backward seed and screen titles for context, tool/action, state/persistence, or orchestration security.
2. Query citing works for each DOI seed; deduplicate citing DOIs.
3. Apply the cutoff and a deliberately broad title filter, then screen title/abstract for agent relevance.
4. Verify publication status from a persistent primary source.
5. Deduplicate against `screened_corpus_v1.md` and separate peer-reviewed studies, preprints, and secondary sources.
6. Promote high-yield additions to the next snowballing round and repeat until no new in-scope record is found.

## Results by round

### Round 1: backward snowballing

- Twelve seed PDFs were processed.
- Fifteen previously missing candidate records were retained.
- The additions comprise 9 peer-reviewed primary studies and 6 primary-study preprints.
- Highest-value additions include AgentHarm, BIPIA, StruQ, ToolCommander, AutoCMD, Breaking Agents, DemonAgent, PoisonedRAG, and several multi-agent/state studies.
- References already present in v1, such as AgentDojo, AgentPoison, TrustAgent, InjecAgent, and the indirect-prompt-injection seed paper, were logged as duplicates rather than counted again.

### Round 1: forward snowballing

- DOI seeds queried: 17.
- Unique citing DOIs returned: 178.
- Records remaining after cutoff and broad title filter: 114.
- Retained after title/abstract screening: 10 (8 peer-reviewed primary studies and 2 secondary studies).
- Exact-title duplicates already represented in v1: 2.
- Excluded at this pass: 102, predominantly because the paper used LLMs for an unrelated domain/cybersecurity task or studied standalone model behavior without an agent/tool/state/orchestration manifestation.

The full machine-collected metadata and the 114-row filter output are preserved as `forward_citations_raw.json` and `forward_citations_filtered.tsv`.

### Round 2

AgentHarm, BIPIA, StruQ, and PoisonedRAG were promoted as high-yield seeds. Exact-title citation chasing and official-page verification added two peer-reviewed studies:

- InstructDetector, a behavioral-state defense evaluated on BIPIA.
- SecureCollaRAG, a Byzantine-tolerant collaborative-RAG defense for agent systems.

Other prominent hits, including Task Shield, MELON, DRIFT, TrustRAG, and AgentPoison, were already represented in v1.

### Round 3

The Round-2 additions and the retrieval-poisoning branch were searched forward by exact title. This added one peer-reviewed study: ShieldRAG, an embedding-space-reshaping defense against retrieval poisoning.

### Round 4 and saturation

ShieldRAG and the other Round-3 branches were searched forward by exact title. No additional in-scope study published on or before 2026-06-30 survived deduplication and screening. Operational saturation was therefore reached for this open-index pass.

## Corpus impact

| Corpus component | v1 | Snowball additions | v2 candidate total |
|---|---:|---:|---:|
| Peer-reviewed primary studies | 33 | 20 | 53 |
| Primary-study preprints | 30 | 6 | 36 |
| Secondary studies/standards/frameworks | 11 | 2 | 13 |
| **Total candidate records** | **74** | **28** | **102** |

The 102 records are a candidate pool, not the final included corpus. Full-text quality and scope screening should reduce the final primary evidence set to roughly 60-70 studies while retaining all 53 peer-reviewed primary records for first-priority assessment.

## Exclusion and status notes

- `E1`: LLM/agent used to perform cybersecurity, education, health, legal, or other tasks; no threat to the agent system itself.
- `E2`: standalone LLM jailbreak, hallucination, ethics, or privacy work with no agent-relevant tool, state, environment, or orchestration mechanism.
- `E3`: tutorial, commentary, or broad review not needed as a secondary comparator.
- `E4`: duplicate or superseded preprint/conference version.
- `E5`: publication date after 2026-06-30. For example, CORBA's Findings of ACL 2026 publication date is 2026-07-02, so it is kept on a watchlist rather than included under the current cutoff.
- `E6`: insufficient metadata or unverifiable publication status.

## Reproducibility and limitations

- OpenCitations has incomplete coverage and indexes the DOI graph more reliably than arXiv-only records.
- Semantic Scholar's public API returned rate-limit errors during this run; it was not treated as a complete source.
- Open indexes cannot substitute for a final Scopus/Web of Science/Google Scholar citation check if institutional access is available.
- PDF-to-text reference extraction is layout-sensitive. Before submission, import all seed bibliographies into a reference manager and record a unique-reference denominator for the final PRISMA flow.
- Search and snowball decisions should be rerun immediately before resubmission to capture status changes from preprint to proceedings publication.
