# Data dictionary

All text tables are UTF-8, tab-delimited. Fields containing tabs, line breaks or quotes in generated supporting tables are quoted using doubled internal quotes. The sealed final TSV also contains literal title quotes in unquoted fields; the supplied parser preserves those titles. Use the supplied scripts if a generic importer changes title punctuation.

## Final core dataset

| Column | Meaning |
|---|---|
| ID | Stable study identifier used across this artifact; prefixes are archival IDs, not analytical subpopulations. |
| Title | Study title. |
| CASO_locations | Semicolon-separated runtime-function labels: C=context/instruction, A=action, S=state/persistence, O=ecosystem/automation. Multiple assignments permitted. |
| Primary_transition_path | One selected evidence-supported assignment, using `>` for ordered transitions; a single node is permitted. `UND` means no uniquely supported primary assignment. |
| Q1 | System and contribution description. |
| Q2 | Threat model and assumptions. |
| Q3 | Evaluation relevance and realism relative to the stated claim. |
| Q4 | Artifacts or operational detail supporting reproducibility. |
| Q5 | Limitations and residual risk. |
| Total | Sum of Q1–Q5, each scored 0, 0.5 or 1. |
| Quality | High: total >=4; Moderate: 3–3.5; Low: <3. Not an inclusion threshold or numerical weight. |
| E_current | E1 output/selection; E2 offline/static/formal analysis; E3 simulated workflow without demonstrated programmatic execution; E4 sandboxed execution/state change; E5 realized real-application effect; E6 physical/mixed-reality validation. |

Endpoint categories distinguish kinds of realization, not a universal ordinal quality scale. Calling a production LLM API does not itself establish E5. An LM-emulated tool result remains E3; hardware used to run software does not itself establish E6. See the method note for boundary rules.

## Supporting datasets

- `core_field_evidence229.json`: all 1,603 final core-field values linked by ID and field to their original independent rationale and source metadata. `independentFirstPass.panel` and `pairIndex` identify the corresponding original pair in the statistics JSON. `finalEvidence.kind` distinguishes 677 active page-anchored adjudications, one retained earlier decision and 925 matching original notes. Original notes and earlier locators are not a fresh final-rule validation; rejected notes are not substituted for final reasons.
- `evidence/central_comparisons.md`: eight targeted source-to-claim checks, with reviewed sources, PDF pages, substantive support and claim boundaries for the central qualitative comparisons.
- `final_core_statistics_2026-10-12.json`: per-study final core values, aggregate calculations, historical provenance, and the original paired judgments used for field-specific agreement. Its `publicExport` describes export transformations and identifies the original sealed JSON hash. Original source paths and obsolete validation counters are not part of the public snapshot.
- `source_index.json`: stable IDs, titles, persistent source links, reviewed arXiv versions when recoverable, source hashes, page counts and descriptive extraction page anchors. `local-provenance/...` labels are identifiers, not files bundled here.
- `descriptive_extraction229.tsv`: original descriptive extraction aligned to final IDs by title. It supplies attacker access, entry/target, mechanisms, settings, models, tasks, controls, metrics, artifacts, limitations and page evidence. It excludes historical Q scores and layer assignments. Missing or NR entries are not evidence of absence.
- `core_field_adjudication.json`: 677 active field decisions from 678 decision events. Decisions include final value, evidence pages and rationale; 620 original disagreement fields are covered. Not every one of the 1,603 core-field values received a fresh coordinator decision. Earlier provenance in the sealed statistics JSON may refer to an earlier decision replaced by a same-valued re-review; this active ledger is the current decision reference.
- `recorded_disagreement_input_2026-10-12.json`: archived historical/independent/final values and evidence for sensitivity replay. Includes rejected labels and distinct original rule versions, not an alternative final dataset.
- `route_selection_cases_2026-10-12.json`: eight purposively selected UND studies with evidence-anchored alternative routes; not an exhaustive breakdown of all 76 UND studies.

## Aggregation

The primary denominator is 229 unless a different population is explicitly named. There are 153 unique supported assignments (148 directed plus five single-node) and 76 UND. Each publication contributes once to its complete selected path. Each multi-hop path contributes once per distinct adjacent edge; repeated occurrences of an edge inside one path do not increase its study incidence.

Path–endpoint profiles group publications by the selected path: C/A-only, S-without-O, S-and-O, O-without-S, or UND. These groups are mutually exclusive; they do not equal overlapping CASO coverage groups. Endpoint and path were extracted separately at publication level, so the table does not establish the endpoint of every edge or selected mechanism.

Original first-pass agreement is reproduced separately for its two panels from the preserved pairs. CASO uses exact set agreement and mean Jaccard; paths use nominal Cohen's kappa including UND; Q scores use linear-weighted kappa on 0/0.5/1. This is not agreement between two fresh final-rule independent codings. Selection agreement is based on the earlier, stratified and boundary-enriched 30-of-88 assessment, not a random sample of the final corpus.
