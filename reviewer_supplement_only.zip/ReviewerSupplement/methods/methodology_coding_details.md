# Supplementary methodology: coding rules and reliability

This document preserves the detailed rules and statistics moved out of Section 3.4 during manuscript compression. It does not replace the authoritative study-level data or introduce new coding decisions.

## Current version and scope (2026-10-12)

This note accompanies the manuscript's 2026-10-12 analytical snapshot. Section 3 preserves an earlier 37-study assessment of endpoint, property, study-role, and auxiliary fields; it is not the full-coverage core-field result. The latter independently assessed 229 studies for CASO, primary path, and Q1–Q5. All 620 original first-pass disagreement fields have now been adjudicated against full-text evidence, including fresh re-review of 39 previously resolved fields. There are 677 active field decisions and 678 decision events; this does not mean all 1,603 core-field values received a fresh coordinator review. Original submissions, rule-alignment rounds, and coordinator decisions remain separate. Section 5 reports the actual first-pass comparisons without treating adjudication as a new blind reliability test.

The current analysis uses `data/final_core_statistics_2026-10-12.json` and its 229-unique-study export `data/final_core229_2026-10-12.tsv`. Core-field provenance is recorded per study and field. Quality labels are recalculated from the adjudicated Q1–Q5 totals: High 213 (93.0%), Moderate 13 (5.7%), and Low 3 (1.3%). Endpoint counts are E1=4, E2=9, E3=99, E4=68, E5=48, and E6=1. Endpoints are retained from `E_current` in the historical extraction records; they were not independently recoded as part of the seven-core-field exercise. Older handover distributions are historical and must not be combined with the current results.

Public checks are `node scripts/reproduce_statistics.mjs` and the two sensitivity-analysis scripts in `scripts/`. These replay the packaged data, not original experiments or a fresh blind application of final rules. Source hashes identify the reviewed files, which are not redistributed. The active evidence-anchored coordinator decisions are in `data/core_field_adjudication.json`.

Eligibility uses first public availability from January 2022 through June 2026. Synthesis uses the full-text revision actually obtained, which may be later. First-publication dates, reviewed revisions, and publication status are distinct; findings are not presented as a census of evidence available by June 2026.

## 1. Extraction and runtime-location assignment

For every included study, extraction covered publication status, study type, attacker capability, entry point, target, agentic and defense mechanisms, models, tasks and datasets, baselines, metrics, evaluation horizon and environment, artifacts, limitations, and page-specific evidence.

CASO assignment follows runtime function rather than data type and permits multiple labels. RAG-store poisoning is state/persistence (S), tool-mediated retrieval is tool/action (A), and consumption of retrieved content is context/instruction (C). A retained condition influencing a later step or session is S. An exchange between agents or external services is ecosystem/automation (O) when the communication boundary forms part of the mechanism; once the received message enters model-visible context, that stage is C. A demonstrated cross-agent message subsequently consumed as input is O→C.

Primary-path coding identifies one supported route per study. The source is the earliest runtime location at which the mechanism is introduced or established; the destination is the furthest downstream location directly evaluated, rather than a hypothetical harm. Defense paths represent transitions monitored or interrupted. Where independent mechanisms have no uniquely supported primary route, the assignment is UND and candidate routes remain in evidence notes. UND also covers insufficient evidence for a unique route; these reasons are conceptually distinct but are not separately counted in the sealed aggregate. UND does not establish absence of route evidence or a reporting deficiency. A directly evaluated single-location mechanism may receive a single-node code. Only evidence-supported ordered feedback receives a return edge. Multi-hop paths are expanded into adjacent directed edges for the transition matrix, counting a study once per supported edge; counts are not transition probabilities or incident-prevalence estimates. These clarifications follow CORE_CODEBOOK v1.1 and the retained adjudication records and do not retroactively claim that every first-pass judgment used the revised conventions.

## 2. Endpoint realization

| Class | Definition |
|---|---|
| E1 | Generated output or selection without execution |
| E2 | Offline, static, or formal analysis |
| E3 | Simulated workflow or decision without demonstrated programmatic tool execution |
| E4 | Actual sandboxed tool/API execution or state change |
| E5 | A security effect realized in a deployed or real application |
| E6 | Physical or mixed-reality validation |

Calling a production LLM API does not itself establish E5. An LM-generated emulation of a tool result remains E3; an actually triggered programmatic tool call in a sandbox can qualify as E4. Physical hardware alone does not qualify software-only outcomes for E6. Secondary observations of verified real-application incidents are marked separately from author-run deployments.

These categories are not a single ordinal strength scale: E1 and E2 identify distinct types of evidence. E4–E6 denotes the explicitly defined set containing sandboxed execution, real-application evidence, and physical/mixed-reality validation. Quality, persistence, recovery, and evaluation duration remain separate constructs. CASO label A may denote a proposed action or tool choice and does not establish execution without endpoint evidence.

## 3. Earlier 37-study independent assessment (historical results)

Samples were sealed before extension coding. An independent reviewer recoded 24 extension studies (Panel R1) and 13 pilot studies (Panel R2), totaling 37 studies and 428 field judgments. Raw exact agreement was 206/428 (48.1%). The aggregate combines nominal, ordered, and multi-label fields and is not an overall reliability coefficient.

- Study role: Cohen's κ = 0.754, n = 37.
- Endpoint realization: linear weighted κ = 0.572, n = 37.
- Security properties: Jaccard = 0.667; category-wise macro κ ≈ 0.52; positive F1 ≈ 0.80. Separate property counts are used rather than exact label-set frequencies.
- Handoff preservation: Panel R1 only, n = 11; nominal κ = 0.368 when NR is a category. Excluding pairs containing NR yields weighted κ = 0.600, but only six pairs remain. This sensitivity result does not establish broad reliability. Pilot recodings did not include safeguard fields.
- Runtime checkpoints: category-wise macro κ ≈ 0.10; positive F1 ≈ 0.16. Detailed checkpoint frequencies cannot support domain-level claims.
- Evaluation horizon, provenance deficiency, and delegated-principal coding likewise do not support quantitative domain-level conclusions.
- These 37-study reliability results do not cover independent CASO, primary-path, or quality-score agreement. Full-coverage coding of those fields is a separate exercise described in the version note above.

Safeguard mechanisms and observed continuations are synthesized qualitatively from anchored study evidence. The current manuscript does not report corpus-wide handoff frequencies. Weakly reproducible auxiliary fields inform illustrative cases or limitations, not headline findings. Missing information is distinguished from evidence that a mechanism or property is absent.

## 4. Synthesis populations and narrative organization

RQ1 uses qualitative property–location relations, not unvalidated property frequencies. RQ2 uses primary paths and adjacent edges. RQ3 compares safeguard mechanisms and the subsequent behavior observed in their evaluations, distinguishing Defense from Mixed studies without reporting a handoff distribution or using old role-population counts as current denominators. RQ4 examines endpoints, quality, and field-specific reliability. An analytical path, an interrupted operation, and a successfully executed attack are not equated.

The primary-assignment populations are 148 directed routes, five single-node assignments, and 76 UND records. C>A is the complete primary-path assignment for 96 studies. The joint path–endpoint table groups publications by their selected assignment; endpoint and route were not systematically paired at the mechanism or experiment level. Counts therefore describe endpoint evidence reported in each publication group, not execution or realization of that particular route. Primary-path groups are not the full set of studies with corresponding multi-label CASO coverage.

A study can contribute to several analyses, but its system, mechanism, and findings receive a full description at one primary narrative home. Attack and propagation studies are primarily discussed under RQ2 and safeguard studies under RQ3; RQ1 and RQ4 emphasize aggregate analyses. Repeated citations contribute different analytical facts rather than repeated study summaries.

## 5. Current core-field first-pass comparison and reconciliation

The table below preserves the former main-text Table 4, "Original first-pass agreement with historical coding, before reconciliation." It was relocated to these supplementary notes on 2026-10-13; no coefficient, denominator, or final coding value changed.

| Field | Initial 37: exact (%) | Initial 37: J or kappa | Further 192: exact (%) | Further 192: J or kappa |
|---|---:|---:|---:|---:|
| CASO locations | 54.1 | J=0.791 | 5.2 | J=0.582 |
| Primary path | 45.9 | 0.290 | 47.9 | 0.126 |
| Q1 | 94.6 | 0.000 | 97.9 | 0.000 |
| Q2 | 51.4 | 0.176 | 77.6 | 0.245 |
| Q3 | 73.0 | 0.464 | 87.5 | 0.230 |
| Q4 | 67.6 | 0.540 | 55.7 | 0.133 |
| Q5 | 78.4 | 0.492 | 50.5 | 0.075 |

These compare historical recorded coding with the original independent submissions under v1.0 (37 studies) and v1.1 (192 studies). CASO uses exact set agreement and mean study-level Jaccard; primary paths use nominal Cohen's kappa, retaining UND; Q1–Q5 use linear-weighted kappa on 0/0.5/1. Historical Q1 is uniformly 1, so kappa is zero despite high exact agreement. Later alignment, nonblind follow-ups, and adjudicated values are not inputs. The two panels are not pooled into a 229-study coefficient.

The 192-study differences include 171 strict expansions among 182 CASO disagreements (94.0%). Of 100 primary-path disagreements, 92 change the node set, four change sequence over the same nodes, and four change UND status. These are substantive coding differences, not order-only notation. Final decisions are traceable in the coordinator ledgers. Independent reproducibility of the final clarified rules has not been demonstrated by a new blind pass; denominator sensitivity is not a test of alternative coding assignments.

The independent second reviewer coded CASO, primary path, and Q1–Q5 without access to the corresponding existing values, recording page-specific evidence and rationales. Tools assisted retrieval and record preparation; the reviewer retained responsibility for judgments. All 620 original core-field disagreements were adjudicated against full texts under the clarified codebook, including re-examination of previously resolved initial-sample disagreements. The adjudication checked runtime functions, path sources and evaluated consequences, and reporting support for quality scores. Original judgments remain distinct from later alignment and adjudicated values: agreement uses the original submissions, while manuscript synthesis uses the final adjudicated dataset. This account does not imply two fresh independent applications of the final codebook.

## 6. Supported-route selection sensitivity (2026-10-12)

This is a bounded coordinator analysis, not a new independent coding round. Eight multipath UND publications were purposively selected for contrasting, identifiable evaluated mechanisms spanning communication, tool registries, state repair, robotics, and heterogeneous benchmarks: A02, N04, N22, A20, U147, U027, N06, and U107. Candidate definitions are fixed for the reported enumeration; this is an exploratory analysis, not a preregistered test. The selection is neither random nor an exhaustive screen of all 76 UND studies. Each has at least two evidence-anchored alternatives; the main codebook still requires UND when a unique study-wide route is not supported.

`data/route_selection_cases_2026-10-12.json` identifies candidate paths, mechanisms and full-text pages. `scripts/analyze_route_selection_2026-10-12.mjs` uses the packaged inputs and source-hash identifiers, enumerates one candidate route per selected publication, and derives path, edge and publication-group counts for all 864 combinations. The other 221 assignments remain fixed. Corpus membership, CASO coverage, endpoints and quality scores are not altered. Endpoints remain publication-level attributes; this exercise does not establish that a candidate mechanism reached its publication's endpoint class.

Reproduce with `node scripts/analyze_route_selection_2026-10-12.mjs --summary`. The complete result, including endpoint matrices and assignments attaining each envelope bound, is saved as `data/route_selection_results_2026-10-12.json` by the `--save` option.

| Quantity | Sealed main value | Range under all eight branch selections |
|---|---:|---:|
| Complete C>A assignments | 96 (41.9% of 229) | 96-98 (41.9-42.8%) |
| S-without-O publications | 23 | 24-28 |
| S-without-O E5-E6 share | 21.7% | 25.0-35.7% |
| O-without-S publications | 23 | 24-27 |
| O-without-S E5-E6 share | 8.7% | 8.3-18.5% |
| UND publications | 76 | 68 |

C>A remains the leading complete resolved path and adjacent edge in every enumerated combination. The smaller groups' proportions change materially, so they are assignment-dependent descriptive results. The ranges are scenario envelopes, not confidence intervals. The sealed main assignments remain unchanged, and 68 is not a revised corpus UND count.

This tests the choice to select one supported branch rather than leave a multipath publication unassigned. It does not quantify uncertainty in other disputed routes, CASO labels or Q scores, or demonstrate independent repeatability under the final codebook. In particular, the fact that endpoint and quality totals remain fixed is a design constraint of this test, not additional validation of those fields.

## 7. Recorded-disagreement stress tests (2026-10-12)

### Target and inputs

This separate exercise targets actual first-pass disagreements, not the choice to compress a multipath paper. It uses all 120 primary-path disagreements (20 in the original 37-study panel, 100 in the further 192-study panel) and all 199 CASO-set disagreements (17 and 182, respectively). The two panels remain separate for reliability reporting; combining their disputed records here defines a stress space, not a pooled agreement coefficient. No case was chosen by its numerical impact.

For each disputed field, the options are the distinct normalized historical, independent first-pass, and adjudicated values. The 109 studies without an original path disagreement retain their final path values; the 30 without a CASO disagreement retain their final sets. This deliberately includes original judgments rejected by adjudication. The options are archived interpretations, NOT newly endorsed evidence-supported alternatives under the final codebook. Different choices can mix codebook versions and need not form one consistently recoded corpus. The test consequently bounds the numerical effect of recorded disagreements without pretending that adjudication itself supplied another independent pass.

Path and CASO tests are FIELDWISE, not a joint recoding. Study membership, endpoints and Q1-Q5 are fixed. Endpoint values remain publication-level, not validated endpoints of hypothetical selected routes. The path-family groups use primary paths; they are not derived from the multi-label CASO coverage test.

### Reproduction and provenance

The public `data/recorded_disagreement_input_2026-10-12.json` is a path-sanitized export of the archived original-submission and decision-ledger replay. Public scripts replay this input without needing private workspace files. The workspace export was checked against the existing seal and source-text hashes for continuity. Hash verification is not a fresh semantic review of original studies. First-pass notes, page references, historical/independent/final values, and the current decision provenance are retained for each case in `recorded_disagreement_results_2026-10-12.json`.

Counts are additive over studies, so exact minimum and maximum counts are obtained by choosing each study's minimizing or maximizing option. Rank margins are checked against every competing resolved path and every competing adjacent edge; UND is not a resolved path. Group ratios are bounded by fixed members and optional E5-E6/non-E5-E6 members. Ratios are defined only when the group is nonempty. Every bound includes an attaining assignment; each bound is marginal and need not be attained simultaneously with other bounds. There is no claim of an enumerated number of independent reviews.

Run `node scripts/analyze_recorded_disagreements_2026-10-12.mjs --summary` for a read-only replay. Portable mode replays the packaged input snapshot but cannot recheck unavailable sources and ledgers. Additional workspace checks independently verified ratio envelopes by dynamic programming; those workspace checks are not required for the public replay.

### Results and use

| Quantity | Main adjudicated value | Recorded-label stress bound |
|---|---:|---:|
| Complete C>A | 96 | 89-176 |
| Complete S>C>A | 6 | 4-30 |
| C>A adjacent-edge incidence | 120 | 104-202 |
| S-without-O publications | 23 | 14-51 |
| S-without-O E5-E6 share | 21.7% | 7.5-56.0% |
| O-without-S publications | 23 | 8-62 |
| O-without-S E5-E6 share | 8.7% | 0.0-63.6% |
| S-and-O publications | 7 | 0-11 |
| S CASO coverage | 195 | 64-216 |
| O CASO coverage | 198 | 87-214 |

Seven final C>A records have original path disagreements: A26, P02, P16, U028, U123, U094 and U046. Unlike the eight-study UND branch test, their C>A labels can be replaced here. The C>A minimum of 89 exceeds the largest competing complete-path maximum of 30. Exact pairwise minimization establishes a minimum lead of 59 studies, and C>A remains the leading adjacent edge with a minimum lead of 70. These ranking findings hold for every assignment in the specified stress space; the complete-path share ranges from 38.9% to 76.9% and is not established as a stable magnitude.

The large small-group and S/O-coverage envelopes demonstrate dependence on recorded interpretations in this deliberately broad space. They are not confidence intervals, plausible-probability estimates, or a claim that rejected labels should be reinstated. In particular, the S-and-O group can be empty; its percentage bounds of 0-100% apply only to nonempty attainable groups and do not describe an empty group's ratio. The main study-level cross-tabulation remains unchanged and conditional on adjudication. Qualitative conclusions rely on the cited mechanism comparisons, not a supposed stable prevalence ranking of S/O research.

The ranking result addresses the numerical consequences of the archived disagreements only. It does not show blind repeatability of final rules, test unrecorded reasonable alternatives, detect shared first-pass errors, or validate fixed endpoints/quality scores. No sealed values, original submissions or adjudication events were edited.

## 8. Selection consistency and search-iteration provenance

The selection-consistency assessment used a stratified 30-study sample from the earlier 88-report pool, including boundary cases. The pool comprised 74 primary reports and 14 background reports at that stage; it is not the final 229-study corpus. Reassessment was conducted without access to the initial eligibility decisions. Pre-reconciliation agreement was 26/30 (86.7%), with Cohen's kappa = 0.727. The four disagreements were resolved using the agentic-eligibility and RAG-boundary rules. These results do not estimate selection agreement for a random sample of the final corpus.

For the final search workflow, the first backward and forward snowballing rounds added 15 and ten candidates, respectively. Rounds 2 and 3 added two and one further candidates. Round 4 yielded no new in-scope study after deduplication and screening, satisfying the predefined saturation rule. These iteration counts sum to the 28 snowballing candidates reported in the manuscript; they do not define separate synthesis populations.
